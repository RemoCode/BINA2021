###Neue Glas-Sammelstellen
##Pakete
install.packages("psych")
library(psych)


##Summary
summary(Pers_Flaeche_Menge_Sammelst)



##Boxplot
#Einwohner:innen
boxplot(Pers_Flaeche_Menge_Sammelst$Einwohner,
        main="Einwohner:innen",
        ylab="Anzahl Personen")

#Siedlungsfläche
boxplot(Pers_Flaeche_Menge_Sammelst$SiedlungsflaecheHA,
        main="Siedlungsfläche",
        ylab="ha")

#Glas-Sammelstellen
boxplot(Pers_Flaeche_Menge_Sammelst$Sammelstellen,
        main="Glas-Sammelstellen",
        ylab="Sammelstellen")

#Menge Glas
boxplot(Pers_Flaeche_Menge_Sammelst$MengeinTonnen,
        main="Menge Glas",
        ylab="Tonnen",
        cex.axis=0.7)




##Hierarchische Clusteranalyse
#Standardisierung
Pers_Flaeche_Menge_Sammelst.scaled <- cbind(scale(Pers_Flaeche_Menge_Sammelst[,5:8]))

#Distanzen bilden
dist.Pers_Flaeche_Menge_Sammelst <- dist(Pers_Flaeche_Menge_Sammelst.scaled[,1:4], method = "euclidean")

#Clustern
fit.1 <- hclust(dist.Pers_Flaeche_Menge_Sammelst, method = "ward.D2")

#Dendrogramm
plot(fit.1, hang = -1, labels=Pers_Flaeche_Menge_Sammelst$Gemeinde,cex=0.4)

#5-Cluster-Lösung
clus.5 <- cutree(fit.1, k=5)

#Cluster in Dendrogramm markieren
rect.hclust(fit.1, k=5, border="red")




##Zürich und Winterthur ausschliessen für K-Means
Pers_Flaeche_Menge_Sammelst_ohneZW <- subset(Pers_Flaeche_Menge_Sammelst, Einwohner<100000)





##k-Means-Clusteranalyse
#Standardisieren
Scale.ohneZW <- scale(Pers_Flaeche_Menge_Sammelst_ohneZW[,5:8])

#Elbow-Methode: Fehlerquadratsummen für verschiedene Cluster berechnen
wss.fit2 <- (nrow(Scale.ohneZW[,1:4])-1)*sum(apply(Scale.ohneZW[,1:4],2,var))
for (i in 2:15){
  wss.fit2[i] <- sum(kmeans(Scale.ohneZW[,1:4], centers=i)$withinss)
}

#Elbow-Methode: Chart
plot(1:15, wss.fit2, type="b",
     xlab="Anzahl cluster",
     ylab="Fehlerquadratsumme")

#K-MEANS - 4 Cluster
fitK <- kmeans(Scale.ohneZW, 4)

#Übersicht
fitK
str(fitK)

#Darstellung
plot(Pers_Flaeche_Menge_Sammelst_ohneZW[,5:8], col=fitK$cluster)

##Infos & Speichern Clustering
Daten.cluster <- fitK$cluster
table(Daten.cluster, Pers_Flaeche_Menge_Sammelst_ohneZW$Gemeinde)
describeBy(Pers_Flaeche_Menge_Sammelst_ohneZW[,5:8], group=Daten.cluster)





##Korrelationen
#Prüfung Normalverteilung - Sammelstellen
qqnorm(Pers_Flaeche_Menge_Sammelst$Sammelstellen)
qqline(Pers_Flaeche_Menge_Sammelst$Sammelstellen)

#Prüfung Normalverteilung - Einwohner:innen
qqnorm(Pers_Flaeche_Menge_Sammelst$Einwohner)
qqline(Pers_Flaeche_Menge_Sammelst$Einwohner)

#Prüfung Normalverteilung - Siedlungsfläche
qqnorm(Pers_Flaeche_Menge_Sammelst$SiedlungsflaecheHA)
qqline(Pers_Flaeche_Menge_Sammelst$SiedlungsflaecheHA)

#Prüfung Normalverteilung - Menge pro Kopf KG
qqnorm(Pers_Flaeche_Menge_Sammelst$MengeproKopfKG)
qqline(Pers_Flaeche_Menge_Sammelst$MengeproKopfKG)

#Korrelationen berechnen - Sammelstellen & Einwohner
cor.test(Pers_Flaeche_Menge_Sammelst$Sammelstellen,
         Pers_Flaeche_Menge_Sammelst$Einwohner, method="kendall")

#Korrelationen berechnen - Sammelstellen & Siedlungsfläche
cor.test(Pers_Flaeche_Menge_Sammelst$Sammelstellen,
         Pers_Flaeche_Menge_Sammelst$SiedlungsflaecheHA, method="kendall")

#Korrelationen berechnen - Sammelstellen & Menge pro Kopf
cor.test(Pers_Flaeche_Menge_Sammelst$Sammelstellen,
         Pers_Flaeche_Menge_Sammelst$MengeproKopfKG, method="kendall")






##Vergleich Sammelstellen pro 1000 Personen & Siedlungsfläche
#Standardisierung
Pers_Flaeche_Menge_Sammelst$ZSammelstellenpro1000Personen <-
  scale(Pers_Flaeche_Menge_Sammelst$Sammelstellenpro1000Personen)

Pers_Flaeche_Menge_Sammelst$ZSammelstellenproSiedlungsflaeche <-
  scale(Pers_Flaeche_Menge_Sammelst$SammelstellenproSiedlungsflaeche)

Pers_Flaeche_Menge_Sammelst$Sammelstellenpro1000Personen_Siedlungsflaeche <-
  Pers_Flaeche_Menge_Sammelst$ZSammelstellenpro1000Personen +
  Pers_Flaeche_Menge_Sammelst$ZSammelstellenproSiedlungsflaeche
